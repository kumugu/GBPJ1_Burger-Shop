echo "# ksite" >> README.md 
git init 
git add README.md 
git commit -m "첫 번째 커밋" 
git branch -M main 
git remote add origin https://github.com/kumugu/ksite.git
 git push -u origin main
