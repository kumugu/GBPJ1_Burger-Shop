package ui.sales;


import javax.swing.*;
import java.awt.*;

public class SalesReportUI extends Component {
    public SalesReportUI() {
        // 패널 기본 설정


        // 컴포넌트 추가

    }
}
