package ui.inventory;

import javax.swing.*;
import java.awt.*;

public class OrderIngredientsUI extends Component {
    public OrderIngredientsUI() {
        // 패널 기본 설정


        // 컴포넌트 추가

    }
}