package service;

public class SalesService {
}
